function [value,isterminal,direction] = virophagedeath_event(t,y,p)

%stopping conditions for integration with ode45.  When virophage becomes
%too small or other populations are sufficiently negative

%value = [y(1)+100, y(2)+100, y(3)-10^(-30), y(4)+100];
value = [y(1)-10^(-30), y(2)-10^(-30), y(3)-10^(-30), y(4)-10^(-30)];
isterminal = [1,1,1,1];
direction=[0,0,0,0];