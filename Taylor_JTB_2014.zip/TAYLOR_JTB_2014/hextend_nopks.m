function [t,x,avg_p] = hextend_nopks(t,x,n,pars,tf)

%Numerically integrate dynamics for for tf time a total of n times.
%Outputs the final time (to check if virophage crash), final population,
%and average of the array of virophage population over the dynamics.
%
%Input: t -- preivious time series.  If the last entry is less than tf than
%               the virophage have crashed and this function does nothing
%       x -- array of dynamics where last row is taken as initial
%               conditions for integration.
%       n -- number times to integrate by tf
%       pars -- parameters
%       tf -- total integration time for iteration.
%
%Output: t -- output time series of last run of dynamics
%        x -- output population dynamics of last run
%        avg_p -- average of the column of the x matrix for  virophage
%           which is used to estimate when the dynamics have converged to a
%           limit cycle.  length of this vector is n.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
avg_p = zeros(1,n);
odeopts=odeset('RelTol',1e-12,'Events',@virophagedeath_event);
count = 0;


    while t(end)==tf && count<n
        count=count+1;
        initcond = x(end,:);
        [t,x,TE,VE,IE] = ode45(@model_hinfect,[0 tf],initcond,odeopts, pars);
        try
            [~,pkinds] = findpeaks(x(:,1));
            avg_p(count) = mean(x(pkinds(1):pkinds(end),3));
        catch
            avg_p(count) = mean(x(:,3));
        end
    end