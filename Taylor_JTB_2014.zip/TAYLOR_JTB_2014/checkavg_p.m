function totalchange = checkavg_p(avg_p)

% Outpusts the sum of the absolute slope of the average virophage
% population over the iterations of integrated dynamics to see if the
% dynamics have converged to a limit cycle
%
%Input: avg_p -- vector of average virophage population over extended
%dynamics.  The vector is ordered and must be have at least 11 elemnts.
%
%Output:    totalchange -- sum of absolute slope of the average virophage
%               dynamics
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        difftestx = diff(avg_p);
        totalchange = sum(abs(difftestx(end-10:end)));