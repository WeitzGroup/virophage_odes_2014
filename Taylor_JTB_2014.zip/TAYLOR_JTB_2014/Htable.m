%Table of Stabilities H


%grab data
clear all
[totalpops,totalpars,totaleigs] = grabdatah(10);


%Allow points with virophage populations greater that 10^-7
[trimpop,trimpar,trimeig] = feasibledata(totalpops,totaleigs,totalpars,10^(-7));
clear('totalpops'); clear('totalpars'); clear('totaleigs');


%Table of stabilities
trimhv = hvonly(trimpar);
[caba,cabr,crba,crbr,caba2,cabr2,crba2,crbr2,coexbistable] = stabilitytableh(trimpar,trimeig,trimhv);


%Stability Table

%Format: U = unstable, S = stable
%
%           Boundary
%           S   U
%C   S      
%o   S
%e   U
%x   SS
%i   SU
%s   UU
%t
%
%Total:

Vstablematrix = [caba cabr;...
                 crba crbr;...
                 coexbistable coexbistable;...
                 caba2 cabr2;...
                 crba2 crbr2;...
                 caba+crba+coexbistable+caba2+crba2,...
                 cabr+crbr+coexbistable+cabr2+crbr2]
             
             %Note: if coexbistable is not zero then stabilitytableh
             %function needs to be edited.