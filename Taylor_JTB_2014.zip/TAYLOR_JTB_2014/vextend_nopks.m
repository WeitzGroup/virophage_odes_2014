function [t,x,avg_p] = vextend_nopks(t,x,n,pars,tf)

avg_p = zeros(1,n);
odeopts=odeset('RelTol',1e-12,'Events',@virophagedeath_event);
    count2 = 0;
    while t(end)==tf & count2<n
        count2=count2+1;
        initcond = x(end,:);
        [t,x,TE,VE,IE] = ode45(@model_vinfect,[0 tf],initcond,odeopts, pars);
        %trim the data
        try
            [~,pkinds] = findpeaks(x(:,1));
            avg_p(count2) = mean(x(pkinds(1):pkinds(end),3));
        catch
            avg_p(count2) = mean(x(:,3));
        end
    end