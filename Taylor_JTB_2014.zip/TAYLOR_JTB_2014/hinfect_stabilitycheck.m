function isstable = hinfect_stabilitycheck(x,p)

%Ouputs true if given equilibrium is linearly stable.  Used for boundary
%equilibria
%
%Input:     x - equilibrium population vector
%           p - respective vector of parameters
%
%Output:    isstable - 1 if linearly stable (all eigenvalues of Jacobian 
%                       are negative), 0 if not.

if sum(x)==0
    isstable = false;
else
b = p(:,1);
d = p(:,2);
K1 = p(:,3);
phip = p(:,4);
phiv = p(:,5);
betav = p(:,6);
mv = p(:,7);
mp = p(:,8);
rhop = p(:,9);
rhovp = p(:,10);
rho = p(:,11);

H=x(:,1);
V=x(:,2);
P=x(:,3);
Hp=x(:,4);

Jacoby = [b+(-1).*d.*(1+(H+Hp).*K1.^(-1))+(-1).*d.*H.*K1.^(-1)+(-1).*P.* ...
phip+(-1).*phiv.*V,(-1).*H.*phiv,(-1).*H.*phip,(-1).*d.*H.*K1.^( ...
 -1)+b.*(1+(-1).*rho);betav.*phiv.*V,(-1).*mv+betav.*phiv.*(H+Hp.* ...
  rhovp),0,betav.*phiv.*rhovp.*V;(-1).*P.*phip,betav.*Hp.*phiv.* ...
 rhop,(-1).*mp+(-1).*H.*phip,betav.*phiv.*rhop.*V;(-1).*d.*Hp.* ...
K1.^(-1)+P.*phip,(-1).*Hp.*phiv,H.*phip,(-1).*d.*(1+(H+Hp).*K1.^( ...
  -1))+(-1).*d.*Hp.*K1.^(-1)+b.*rho+(-1).*phiv.*V];
    eigens= eig(Jacoby);
    isstable = (numel(eigens(real(eigens)>=0))==0);
end
        