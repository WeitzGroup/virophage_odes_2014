function [trimpop,trimpar,trimeig] = feasibledata(totalpops,totaleigs,totalpars,threshold)

%Trim data so that virophage and infected populations are greater than some
%threshold
%
%Input: totalpops -- data of equilibrium populations nx4 matrix
%       totaleigs -- respective eigenvalues for linear stability at
%                       equilibria. nx4 matrix
%       totalpars -- respective parameter sets. nx11 matrix
%       threshold -- minimum population size for virophage or infected
%                       class in trimmed data
%
%Output: trimpop  -- trimmed population data
%        trimpar  -- trimmed parameter sets
%        trimeig  -- trimmed eigenvalues

iscoex = totalpops(:,3)>threshold & totalpops(:,4)>threshold;
trimpop = totalpops(iscoex,:);
trimpar = totalpars(iscoex,:);
trimeig = totaleigs(iscoex,:);
