%Script that identifies basin of attraction along +Vp direction from
%coexistence equilibrium

%grab data (default resamples=10)
clear all
[totalpops,totalpars,totaleigs] = grabdatav(10);


%Allow points with virophage populations greater that 10^-7
[trimpop,trimpar,trimeig] = feasibledata(totalpops,totaleigs,totalpars,10^(-7));
clear('totalpops'); clear('totalpars'); clear('totaleigs');

%Consider only stable coexistence points
isstable = sum(trimeig>=0,2)<1;
coexpop = trimpop(isstable,:);
coexpar = trimpar(isstable,:);
coexeig = trimeig(isstable,:);

%Bistable figure start
hvpop = hvonly(coexpar);
vposhv = sum(hvpop>0,2);
hvpop(vposhv<2,:) = 0;
hvpop = [hvpop zeros(size(hvpop,1),2)];
vhvstable = false(size(hvpop,1),1);
for k=1:size(hvpop,1)
    vhvstable(k,1) = vinfect_stabilitycheck(hvpop(k,:),coexpar(k,:));
end

%Reduce filled memory if dealing with larger datasets
clear trimpop
clear trimeig
clear trimpar
clear totalpars
clear totaleigs
clear hvpop
clear isstable

%Determine Bistable points
bistableind = find(vhvstable);
bipop = coexpop(bistableind,:);
bipar = coexpar(bistableind,:);
bieig = coexeig(bistableind,:);
hvpop = hvonly(bipar);
hvpop = [hvpop zeros(size(hvpop,1),2)];

%Reduce filled memory further
clear coexeig
clear coexpar
clear coexpop

%Resume from previous data if it exists
try
        load('data/lastup_vp_up','lastup_vp_up')
        load('data/lastdown_vp_up','lastdown_vp_up')
end


%Bisection method start

%Simulation parameters

%number of points to identify
npts = 1000;

%Threshold to determine convergence
minthresh = 10.^(-6);   %Crash occurs when virophage is below this value
maxthresh = .99;         %Coexistence occurs when virophage is above this value
maxmaxthresh = 1.01;     %and above this one

%Number of loops to attempt finding solution before giving up
numiters = 7;      %Bisections above
totcounts=15;     %number of times to exponentially increase integration time

%initial simulation time
tfmin = 100;

%Start at last unfilled space of data, if data exists
try
    nstart = length(lastup_vp_up)+1;
catch
    nstart = 1;
end

%run bisection
for j = nstart:npts

	%find coex pop and boundary pop and parameters
    hpop = bipop(j,1);
    vhvpop = bipop(j,:);
    par = bipar(j,:);
    
    %run bisect and save
    [lastup_vp_up(j),lastdown_vp_up(j)]=bisection_function_fromcoex_exp(0,1+(1/2)^numiters,numiters,4,par,vhvpop,minthresh,maxthresh,maxmaxthresh,tfmin,totcounts);
	save('data/lastup_vp_up','lastup_vp_up')
	save('data/lastdown_vp_up','lastdown_vp_up')
        
end