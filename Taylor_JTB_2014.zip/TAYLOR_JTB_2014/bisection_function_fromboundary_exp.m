function [lastup,lastdown] = bisection_function_fromboundary_exp(lastup,lastdown,numiters,vhpop,par,pop,minthresh,maxthresh,maxmaxthresh,tfmin,totcounts)


%-------------------------------------------------------------------------
%runs bisection method for identifying boundary of the basin of attraction
%along the virophage axis of phase space along the boundary equilibrium
%slice (specifically H=H_b V=V_b V_p = 0)
%
%Input: lastup -- maximum virophage density boundary for bisection
%       lastdown -- minimum virophage density boundary for bisection
%       numiters -- maximum number of bisections to be taken
%       vhpop     -- boundary equilibrium of host and viruses alone
%       par     -- parameter set
%       pop   -- coexistence virophage population
%       minthresh -- fraction of virophage coexistence equilibrium below
%                       which the population is considered to crash
%       maxthresh -- fraction of virophage coexistence equilibrium above
%                       which the population is considered to have fixed as
%                       long as it is below maxmaxthresh
%       maxmaxthresh -- fraction of virophage coexistence equilibrium below
%                       which the population is considered to have fixed as
%                       long as it is above maxthresh
%       tfmin   -- Minimum time to integrate the dynamics
%       totcounts -- number of times to extend dynamics by 300%
%
%Output: lastup -- upperbound on the boundary of the basin of attraction
%        lastdown -- lowerbound on the boundary of the basin of attraction
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

k=0;
xinit = vhpop;

    
%bisect a number of predetermined times
while k < numiters
    k=k+1;
    initp = lastup-((lastup - lastdown)./2);
    initpact = (10^initp).*pop;
    xinit(3) = initpact;
    [ratout,xfin]= virophage_convergence(pop,xinit,par,tfmin,minthresh,maxthresh,maxmaxthresh,totcounts);
                
                
    %Final check convergence and track if virophage fixed or crashed
                
    %Fixed
    if (ratout>maxthresh && ratout<maxmaxthresh && xfin(1)>10^(-30) && xfin(2)>10^(-30))
        lastup = initp;
                    
    %Crashed
    elseif ratout<minthresh || xfin(1)<10^(-30) || xfin(2)<10^(-30)
        lastdown = initp;
                    
    %Neither, Prematurely end loop
    elseif (ratout<maxthresh || ratout>maxmaxthresh) && ratout>minthresh && xfin(1)>10^(-30) && xfin(2)>10^(-30)
        k=numiters;
    end
end