%Figure 5cd: Vinfect virophage effect on host/virus

%grab data
clear all
[totalpops,totalpars,totaleigs] = grabdatav(10);


%Allow points with virophage populations greater that 10^-7
[trimpop,trimpar,trimeig] = feasibledata(totalpops,totaleigs,totalpars,10^(-7));
clear('totalpops'); clear('totalpars'); clear('totaleigs');

%Consider only stable coexistence points

isstable = sum(trimeig>=0,2)<1; %only points with all negative eigenvalues
coexpop = trimpop(isstable,:);  %populations
coexpar = trimpar(isstable,:);  %respective parameters
coexeig = trimeig(isstable,:);  %respective eigenvalues

hvpop = hvonly(coexpar);    %boundary equilibria populations


%figure5c: Virophage affect on Host
figure(1)
hvpop = hvonly(coexpar);
scatterhist(log10(hvpop(:,1)),log10(coexpop(:,1)))
title('Effect of P on H in PEM','Fontsize',20)
ylabel('Log_{10} H density w/ P','Fontsize',20)
xlabel('Log_{10} H Density w/o P','Fontsize',20)
set(gca,'Fontsize',20)
hold on
loglog([min(log10(coexpop(:,1)))  max(log10(coexpop(:,1)))],[min(log10(coexpop(:,1)))  max(log10(coexpop(:,1)))],'r','Linewidth',3)
hold off
axis([min(log10(coexpop(:,1)))  max(log10(coexpop(:,1))) min(log10(coexpop(:,1)))  max(log10(coexpop(:,1)))])


%figure5d: Virophage affect on Virus
figure(2)
scatterhist(log10(hvpop(:,2)),log10(coexpop(:,2)+coexpop(:,4)))
title('Effect of P on V in PEM','Fontsize',20)
ylabel('Log_{10} V+V_p Density w/ P','Fontsize',20)
xlabel('Log_{10} V Density w/o P','Fontsize',20)
set(gca,'Fontsize',20)
hold on
loglog([min(log10(coexpop(:,2)+coexpop(:,4)))  max(log10(coexpop(:,2)+coexpop(:,4)))],[min(log10(coexpop(:,2)+coexpop(:,4)))  max(log10(coexpop(:,2)+coexpop(:,4)))],'r','Linewidth',3)
hold off
axis([min(log10(hvpop(:,2)))  max(log10(coexpop(:,2)+coexpop(:,4)))  min(log10(hvpop(:,2)))  max(log10(coexpop(:,2)+coexpop(:,4)))])