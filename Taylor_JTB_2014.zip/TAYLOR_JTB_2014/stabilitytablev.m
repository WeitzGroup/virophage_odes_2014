function [caba,cabr,crba,crbr,caba2,cabr2,crba2,crbr2,coexbistable] = stabilitytablev(existpars,existeigs,existhv)

%Generates data for use in the linear stability tables in Hinfect model
%
%Input:     existpars - matrix of parameter sets
%           existeigs - matrix of eigenvalues of Jacobian for linear
%                       stability
%           existhv   - matrix of respective boundary equilibra
%
%Output:    The convention is point followed by stability where 'c' refers 
%           to coexistence point, 'b' refers to boundary point, 'a' refers 
%           to attracting/stable, 'r' refers repelling/unstable, '2' refers
%           to multiple coexistent points existing for a single parameter
%           set.
%           coexbistable - check for bistability between coexistent points

%total number of points
numcoex = size(existhv,1);

%set negative hv populations to 0
poshv = sum(existhv>0,2);
existhv(poshv<2,:) = 0;
existhv = [existhv zeros(numcoex,2)];

%Stability of boundary equilibria
existhvstable = zeros(numcoex,1);
for k=1:numcoex
    existhvstable(k,1) = vinfect_stabilitycheck(existhv(k,:),existpars(k,:));
end

%determine where multiple coexistence points exist
multind = find(diff(existpars(:,1))==0);


%separate when mulitple, grab eigs
firsteigs = existeigs(multind,:);
secondeigs = existeigs(multind+1,:);
existeigs(union(multind,multind+1),:) = [];

%separate hv into multiple or single
firsthvstable = existhvstable(multind,:);
existhvstable(union(multind,multind+1),:) = [];

%stability logic arrays
isstable = sum(existeigs>0,2)<1;
firststable = sum(firsteigs>0,2)<1;
secondstable = sum(secondeigs>0,2)<1;

%different combinatorics
caba = sum(isstable.*existhvstable);
cabr =sum(isstable.*~existhvstable);
crba = sum(~isstable.*existhvstable);
crbr = sum(~isstable.*~existhvstable);

caba2 = sum((firststable | secondstable).*firsthvstable);
cabr2 =sum((firststable | secondstable).*~firsthvstable);
crba2 = sum((~firststable & ~secondstable).*firsthvstable);
crbr2 = sum((~firststable & ~secondstable).*~firsthvstable);

coexbistable = sum((firststable & secondstable));