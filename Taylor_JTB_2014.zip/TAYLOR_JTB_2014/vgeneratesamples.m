function s = vgeneratesamples(numsamps,ordersmag)

%samples parameter space by LHS around reference parameters in Hinfect model
%
%Input: numsamps -- number of samples
%       ordersmag-- orders of magnitude above and below reference
%                   parameters to sample in log space
%
%Output:    s    -- output parameter sets numsamps x 11 matrix

pvtemp = parameters(1);
origparams = struct2array(pvtemp);
numparams = numel(origparams);
numratioparams = 2;

                % Use LHS to sample log parameters
s = LHSmid(numsamps,ones(numparams-numratioparams,1).*(-1.*ordersmag),ones(numparams-numratioparams,1).*ordersmag);
prodmat = repmat(origparams(1:numparams-numratioparams),numsamps,1);
s = prodmat.*(10.^s);


%sample randomly and force rho_i+rho_vp<1
%pre-allocate
s = [s, zeros(numsamps,2)];
    
count=1;
while count<=numsamps
    dart = rand(1,2);
    while 1<sum(dart)
        dart = rand(1,2);
    end
    s(count,end-1:end) = dart;
    count=count+1;
end