function fdots = model_vinfect(t,x,p)

%Vinfect model dynamical system called in ode45


H = x(1);
V = x(2);
P = x(3);
Vp = x(4);


b = p(:,1);
d = p(:,2);
K = p(:,3);
phivp = p(:,4);
phiv = p(:,5);
betav = p(:,6);
mv = p(:,7);
mp = p(:,8);
rhop = p(:,9);
rhovp = p(:,10);
rhoi = p(:,11);

betaVp = rhovp*betav;
betaI = rhoi.*betav;%15;%5;
betap = rhop*betav;%20;

Hdot = H.*(b-d.*(1+H./K))-phiv.*(V+Vp).*H;
Vpdot = phivp.*V.*P-(mv+mp).*Vp+betaI.*phiv.*Vp.*H;
Vdot = (betav.*V+betaVp.*Vp).*phiv.*H-phivp.*V.*P+(mp).*Vp-mv.*V;
Pdot = betap.*phiv.*Vp.*H-phivp.*(V).*P+(mv).*Vp-mp.*P;%-phic*Vc*c;
fdots = [Hdot;Vdot;Pdot;Vpdot];