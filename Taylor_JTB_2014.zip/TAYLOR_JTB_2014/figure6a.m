%Figure 6a: Bistable Dynamics
%This figure is hardcoded to match the example in the paper and may not
%identify dynamics across the basin of attraction boundary for your point.
%Edit initialcondvec to alter this.

%grab data
close all
clear all
[totalpops,totalpars,totaleigs] = grabdatav(10);


%Allow points with virophage populations greater that 10^-7
[trimpop,trimpar,trimeig] = feasibledata(totalpops,totaleigs,totalpars,10^(-7));
clear('totalpops'); clear('totalpars'); clear('totaleigs');

%Consider only stable coexistence points

isstable = sum(trimeig>=0,2)<1;
coexpop = trimpop(isstable,:);
coexpar = trimpar(isstable,:);
coexeig = trimeig(isstable,:);



%Bistable figure start
hvpop = hvonly(coexpar);
vposhv = sum(hvpop>0,2);
hvpop(vposhv<2,:) = 0;
hvpop = [hvpop zeros(size(hvpop,1),2)];
vhvstable = false(size(hvpop,1),1);
for k=1:size(hvpop,1)
    vhvstable(k,1) = vinfect_stabilitycheck(hvpop(k,:),coexpar(k,:));
end


%sort by closeness to reference
clear logdistpars
clear hvpop
bistableind = find(vhvstable);
bipar = coexpar(bistableind,:);
bieig = coexeig(bistableind,:);
bipop = coexpop(bistableind,:);
hvpop = hvonly(bipar);
hvpop = [hvpop zeros(size(hvpop,1),2)];

%Sort data to grab one near reference point
sortparind = sortparsv(bipar);



%Multicoex
%basin of attraction figure
samp = sortparind(1);
tf1 = 600;
initialcondvec = 4:.5:6;
initialcondvec = 10.^initialcondvec;
odeopts=odeset('RelTol',1e-8);
close all
for k=1:2
    [t{k},x{k}] = ode45(@model_vinfect,[0 tf1],hvpop(samp,:)+[0,0,initialcondvec(k),0],odeopts, bipar(samp,:));
    semilogy(t{k},x{k}(:,3),'r--','Linewidth',3)
    test(k,:) = get(gca,'ylim');
    hold on
end

for k=3:length(initialcondvec)
    [t{k},x{k}] = ode45(@model_vinfect,[0 tf1],hvpop(samp,:)+[0,0,initialcondvec(k),0],odeopts, bipar(samp,:));
    semilogy(t{k},x{k}(:,3),'r','Linewidth',3)
    test(k,:) = get(gca,'ylim');
end
test = get(gca,'ylim');



     start = 100;
     stop = 500;
     
     plot(tf1,bipop(samp,3),'o','LineWidth',3,'MarkerSize',15,'MarkerEdgeColor','k','MarkerFaceColor','r')
     ylim(test)
     
     excisevec = [start stop];


set(gca,'YTick',[10^-6 10^-4 10^-2 10^0 10^2 10^4 10^6 10^8])


xlabel('Time (days)','Fontsize',20)
ylabel('Density (ml^{-1})','Fontsize',20)
set(gca,'Fontsize',20)
hold off
h=breakxaxis2(excisevec);

