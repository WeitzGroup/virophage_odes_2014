%Script to generate basin of attraction boundary from the boundary
%equilibrium along virophage direction

%grab data (default resamples=10)
clear all
[totalpops,totalpars,totaleigs] = grabdatav(10);


%Allow points with virophage populations greater that 10^-7
[trimpop,trimpar,trimeig] = feasibledata(totalpops,totaleigs,totalpars,10^(-7));
clear('totalpops'); clear('totalpars'); clear('totaleigs');

%Consider only stable coexistence points
isstable = sum(trimeig>=0,2)<1;
coexpop = trimpop(isstable,:);
coexpar = trimpar(isstable,:);
coexeig = trimeig(isstable,:);

%Obtain boundary equilibria and identify stability
hvpop = hvonly(coexpar);
hvpop = [hvpop zeros(size(hvpop,1),2)];
vhvstable = false(size(hvpop,1),1);
for k=1:size(hvpop,1)
    vhvstable(k,1) = vinfect_stabilitycheck(hvpop(k,:),coexpar(k,:));
end

%Reduce filled memory for when dealing with larger datasets
clear trimpop
clear trimeig
clear trimpar
clear totalpars
clear totaleigs
clear hvpop
clear isstable

%Determine Bistable points
bistableind = find(vhvstable);
bipop = coexpop(bistableind,:);
bipar = coexpar(bistableind,:);
bieig = coexeig(bistableind,:);
hvpop = hvonly(bipar);
hvpop = [hvpop zeros(size(hvpop,1),2)];

%Reduce filled memory further
clear coexeig
clear coexpar
clear coexpop

%Resume from previous data if it exists
try
        load('data/lastup_fromboundary','lastup')
        load('data/lastdown_fromboundary','lastdown')
end


%Bisection method start

%Simulation parameters

%number of points to identify
npts = 1000;

%Threshold to determine convergence
minthresh = 10.^(-6);   %Crash occurs when virophage is below this value
maxthresh = .99;         %Coexistence occurs when virophage is above this value
maxmaxthresh = 1.01;     %and above this one

%Number of loops to attempt finding solution before giving up
numiters = 9;      %Bisections above
numiters2 = 9;     %Bisections below
totcounts = 10;      %number of times to exponentially increase integration time

%initial simulation time
tfmin = 100;



%Start at last unfilled space of data, if data exists
try
    nstart = length(lastup)+1;
catch
    nstart = 1;
end



%run bisection
for j = nstart:npts
    %find coex pop and boundary pop and parameters
    pop = bipop(j,3);
    vhvpop = hvpop(j,:);
    par = bipar(j,:);
    
    %Start initially at virophage coex population
    initp = 1;
    tf=tfmin;
    initpact = initp.*pop;
    xinit = vhvpop+[0,0,initpact,0];
    [ratout,xfin] = virophage_convergence(pop,xinit,par,tfmin,minthresh,maxthresh,maxmaxthresh,totcounts);
    
    %Check convergence
    if ratout>minthresh && (ratout<maxthresh || ratout>maxmaxthresh)
        lastup(j) = NaN;
        lastdown(j) = NaN;
    elseif ratout<minthresh
        initmove = 0;       %0 -- perturb by coexist virophage pop crashes
    elseif ratout>maxthresh
        initmove = 1;       %1 -- perturb by coexist virophage pop fixes
    end
    
    
    
    
    %first move down
    if initmove==0
        initp = 10^4;
        tf=tfmin;
        initpact = initp.*pop;
        xinit = vhvpop+[0,0,initpact,0];
        %[ratout,xfin] = virophage_convergence(pop,xinit,par,tfmin,minthresh,maxthresh,maxmaxthresh);
        [ratout,xfin] = virophage_convergence(pop,xinit,par,tfmin,minthresh,maxthresh,maxmaxthresh,totcounts);
        
        %If no convergence
        if ratout>minthresh && (ratout<maxthresh || ratout>maxmaxthresh) %firstcount == 10
            lastup(j) = NaN;
            lastdown(j) = NaN;
            
            
            %Convergence below set to arbitrary lower bound that signifies
            %basin of attraction is below the observed area
        elseif ratout<minthresh
            lastup(j) = 6;
            lastdown(j) = 6;
            
            
            %Basin of attraction lies in between areas, perform bisection.
        elseif ratout>maxthresh
            lastdown(j) = 0;
            lastup(j) = 4;

            [lastup(j),lastdown(j)]=bisection_function_fromboundary_exp(lastup(j),lastdown(j),numiters,vhvpop,par,pop,minthresh,maxthresh,maxmaxthresh,tfmin,totcounts);
            
        end
        
    end
        

    
    
    
    %First move up
    if initmove==1
        initp = 10^(-4);
        tf=tfmin;
        initpact = initp.*pop;
        xinit = vhvpop+[0,0,initpact,0];
        [ratout,xfin] = virophage_convergence(pop,xinit,par,tfmin,minthresh,maxthresh,maxmaxthresh,totcounts);
        
        if ratout>minthresh && (ratout<maxthresh || ratout>maxmaxthresh) %firstcount == 10
            lastup(j) = NaN;
            lastdown(j) = NaN;
        elseif ratout>maxthresh
             lastup(j) = -6;
            lastdown(j) = -6;
        elseif ratout<minthresh
            lastdown(j) = -4;
            lastup(j) = 0;
            
            [lastup(j),lastdown(j)]=bisection_function_fromboundary_exp(lastup(j),lastdown(j),numiters,vhvpop,par,pop,minthresh,maxthresh,maxmaxthresh,tfmin,totcounts);
        end
    end
        save('data/lastup_fromboundary','lastup')
        save('data/lastdown_fromboundary','lastdown')
end