function sortparind = sortparsh(coexpar)

%For Hinfect model, sort parameter sets by L1 distance from reference
%parameter set
%
%Input: coexpar - matrix of parameter sets
%
%Output:sortparind - sorted matrix of parameter sets

%respective parameter set
refpars = struct2array(parameters(2));

%log distance for logarithmically sampled parameters
logdistpars(:,1:9) = log10(coexpar(:,1:9)./repmat(refpars(1:9),size(coexpar,1),1));

%lin distance for linearly sampled parameters
logdistpars(:,10:11) = coexpar(:,10:11)-repmat(refpars(10:11),size(coexpar,1),1);

%L1 distance
sumpardist = sum(abs(logdistpars),2);
[~,sortparind] = sort(sumpardist);