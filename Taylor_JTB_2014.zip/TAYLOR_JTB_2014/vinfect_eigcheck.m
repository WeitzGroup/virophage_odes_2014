function isstable = vinfect_eigcheck(x,p)

%function isstable = vinfect_eigcheck(x,p)
%
%gives numerical eigenvalues to jacobian for the boundary equilibrium
%
%Input: x -- 1x4 vector of boundary equilibrium, [H,V,0,0]
%       p -- vector of parameters
%
%Output: isstable -- vector of eigenvalues of jacobian
%----------------------------------------------------------------------

if sum(x)==0
    isstable = [NaN NaN NaN NaN];
else
b = p(:,1);
d = p(:,2);
K1 = p(:,3);
phivp = p(:,4);
phiv = p(:,5);
betav = p(:,6);
mv = p(:,7);
mp = p(:,8);
rhop = p(:,9);
rhovp = p(:,10);
rhoi = p(:,11);

H = x(:,1);
V = x(:,2);
P = x(:,3);
Vp = x(:,4);
Jacoby = [b+(-1).*d.*(1+H.*K1.^(-1))+(-1).*d.*H.*K1.^(-1)+(-1).*phiv.*(V+ ...
 Vp),(-1).*H.*phiv,0,(-1).*H.*phiv;betav.*phiv.*(V+rhovp.*Vp),(-1) ...
  .*mv+betav.*H.*phiv+(-1).*P.*phivp,(-1).*phivp.*V,mp+betav.*H.* ...
  phiv.*rhovp;betav.*phiv.*rhop.*Vp,(-1).*P.*phivp,(-1).*mp+(-1).* ...
  phivp.*V,mv+betav.*H.*phiv.*rhop;betav.*phiv.*rhoi.*Vp,P.*phivp, ...
  phivp.*V,(-1).*mp+(-1).*mv+betav.*H.*phiv.*rhoi];
    isstable= eig(Jacoby);
    %isstable = (numel(eigens(real(eigens)>=0))==0);
end
        