%Figure 4b: Vinfect population histogram

%grab data
clear all
[totalpops,totalpars,totaleigs] = grabdatav(10);


%Allow points with virophage populations greater that 10^-7
[trimpop,trimpar,trimeig] = feasibledata(totalpops,totaleigs,totalpars,10^(-7));
clear('totalpops'); clear('totalpars'); clear('totaleigs');

%Consider only stable coexistence points

isstable = sum(trimeig>=0,2)<1; %only points with all negative eigenvalues
coexpop = trimpop(isstable,:);  %populations
coexpar = trimpar(isstable,:);  %respective parameters
coexeig = trimeig(isstable,:);  %respective eigenvalues

hvpop = hvonly(coexpar);    %boundary equilibria populations


%figure4b: Population Histogram
hvpop = hvonly(coexpar);    %boundary equilibria populations
[histy,xers] = hist(log10(coexpop),80);
plot(xers,histy,'LineWidth',3)
title('PEM Coexistence Populations','Fontsize',20)
ylabel('Frequency','Fontsize',20)
xlabel('Log_{10}(Density)','Fontsize',20)
legend('H','V','P','V_p')
set(gca,'Fontsize',20)

%Boundary equilibria histogram
hold on
[histz,zers] = hist(log10(hvpop(:,1:2)),80);
plot(zers,histz,'--','LineWidth',3)
hold off
xlim([-5.4600 13.794488027307796])