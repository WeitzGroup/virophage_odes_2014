function sortparind = sortparsv_bd(coexpar)

%For Vinfect model, sort parameter sets by L1 distance from reference
%parameter set with respect to b and d parameters only
%
%Input: coexpar - matrix of parameter sets
%
%Output:sortparind - sorted matrix of parameter sets

%reference parameter set
refpars = struct2array(parameters(1));

%log distance
logdistpars(:,1:2) = log10(coexpar(:,1:2)./repmat(refpars(1:2),size(coexpar,1),1));

%L1 distance
sumpardist = sum(abs(logdistpars),2);
[~,sortparind] = sort(sumpardist);