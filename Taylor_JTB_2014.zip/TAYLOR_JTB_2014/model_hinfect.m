function fdots = model_hinfect(t,x,p)

%Hinfect model dynamical system called in ode45

H = x(1);
V = x(2);
P = x(3);
Hp = x(4);


b=p(1);
d=p(2);
K=p(3);
phip=p(4);
phiv= p(5);
betav=p(6);
mv=p(7);
mp=p(8);
rhop=p(9);
rhovp=p(10);
rho=p(11);

Hdot = H.*(b-d.*(1+(H+Hp)./K))+...
    (1-rho).*Hp.*b-phip.*H.*P-phiv.*V.*H;
Vdot = (rhovp.*betav.*Hp+betav.*H).*phiv.*V-mv.*V;
Pdot = rhop.*betav.*phiv.*V.*Hp-mp.*P-phip.*H.*P;
Hpdot = Hp.*(rho.*b-d.*(1+(H+Hp)./K))...
    +phip.*H.*P-phiv.*V.*Hp;
fdots = [Hdot;Vdot;Pdot;Hpdot];

end