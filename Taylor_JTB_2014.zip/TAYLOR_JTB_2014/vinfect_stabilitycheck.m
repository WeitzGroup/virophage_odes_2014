function isstable = vinfect_stabilitycheck(x,p)

%Ouputs true if given equilibrium is linearly stable.  Used for boundary
%equilibria
%
%Input:     x - equilibrium population vector
%           p - respective vector of parameters
%
%Output:    isstable - 1 if linearly stable (all eigenvalues of Jacobian 
%                       are negative), 0 if not.

if sum(x)==0
    isstable = false;
else
b = p(:,1);
d = p(:,2);
K1 = p(:,3);
phivp = p(:,4);
phiv = p(:,5);
betav = p(:,6);
mv = p(:,7);
mp = p(:,8);
rhop = p(:,9);
rhovp = p(:,10);
rhoi = p(:,11);

H = x(:,1);
V = x(:,2);
P = x(:,3);
Vp = x(:,4);
Jacoby = [b+(-1).*d.*(1+H.*K1.^(-1))+(-1).*d.*H.*K1.^(-1)+(-1).*phiv.*(V+ ...
 Vp),(-1).*H.*phiv,0,(-1).*H.*phiv;betav.*phiv.*(V+rhovp.*Vp),(-1) ...
  .*mv+betav.*H.*phiv+(-1).*P.*phivp,(-1).*phivp.*V,mp+betav.*H.* ...
  phiv.*rhovp;betav.*phiv.*rhop.*Vp,(-1).*P.*phivp,(-1).*mp+(-1).* ...
  phivp.*V,mv+betav.*H.*phiv.*rhop;betav.*phiv.*rhoi.*Vp,P.*phivp, ...
  phivp.*V,(-1).*mp+(-1).*mv+betav.*H.*phiv.*rhoi];
    eigens= eig(Jacoby);
    isstable = (numel(eigens(real(eigens)>=0))==0);
end
        