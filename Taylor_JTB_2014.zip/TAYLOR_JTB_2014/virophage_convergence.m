function [ratout,xfin] = virophage_convergence(pop,xinit,par,tfmin,minthresh,maxthresh,maxmaxthresh,totcounts)

%---------------------------------------------------------------------
%Integrates dynamics until the virophage are below some threshold and are
%expected to crash or within a neighborhood of the coexistence virophage 
%density such that they are expected to fix.
%
%Input: pop -- virophage coexistence equilibrium density
%       xinit -- intital conditions for population dynamics
%       par -- parameter set
%       tfmin -- minimum amount of time to integrate
%       minthresh -- fraction of virophage coexistence equilibrium below
%                       which the population is considered to crash
%       maxthresh -- fraction of virophage coexistence equilibrium above
%                       which the population is considered to have fixed as
%                       long as it is below maxmaxthresh
%       maxmaxthresh -- fraction of virophage coexistence equilibrium below
%                       which the population is considered to have fixed as
%                       long as it is above maxthresh
%
%Output: ratout -- ratio of the coexistent virophage population that the
%           final virophage population is after numerical integration
%       xfin -- final population density for host, virus, virophage, and
%                   infected class after numerical integration
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[ratout,xfin] = crashchecklin(pop,xinit,par,tfmin);
firstcount = 0;
tf= tfmin;
    
%if not converge extend integrationtime exponentially
while xfin(1)>10^(-30) && ratout>minthresh && (ratout<maxthresh || ratout>maxmaxthresh) && firstcount<totcounts
    firstcount = firstcount+1;
    tf = tf*3;
    [ratout,xfin] = crashchecklin(pop,xfin,par,tf);
end

end



function [finrat,xfin] = crashchecklin(pop,xinit,par,tf)

%Integrate Vinfect model to check convergence to equilibrium in Bistable
%parameter sets.
%
%Input: initp -- multiple of virophage equilibrium to introduce
%       pop   -- virophage equilibrium
%       xinit -- initial populations 1x4 vector
%       par   -- vector of parameter values
%       tf    -- total integration time
%
%Output:finrat -- final virophage population as a ratio of equilibrium
%                   virophage population
%       xfin   -- total populations at tf

odeopts=odeset('RelTol',1e-12,'Events',@virophagedeath_event);
%odeopts=odeset('RelTol',1e-12);
[~,x] = ode15s(@model_vinfect,[0  tf./2 tf],xinit,odeopts, par);
finrat = x(end,3)./pop;
xfin = x(end,:);

end