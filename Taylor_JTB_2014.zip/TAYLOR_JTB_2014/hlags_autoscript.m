%Script for automatically calculating phase lags between populations during cyclical
%dynamics.  The integration perturbs from the coexistence equilibrium and
%integrates forward until the dynamics have converged onto a limit cycle.
%Since dynamics can vary this script can make errors but leaves signals in
%the output where the user can identify problem cases and can manually fix
%later.


%grab data
clear all
[totalpops,totalpars,totaleigs] = grabdatah(10);


%Allow points with virophage populations greater that 10^-7
[trimpop,trimpar,trimeig] = feasibledata(totalpops,totaleigs,totalpars,10^(-7));
clear('totalpops'); clear('totaleigs'); clear('totalpars');


%Trim data for potential cyclical dynamics
clear isstable
isstable = sum(trimeig>=0,2)>0;
limpop = trimpop(isstable,:);
limpar = trimpar(isstable,:);
limeig = trimeig(isstable,:);
clear('trimpop'); clear('trimpar'); clear('trimeig');


try
    %load previous data
    load('data/hlagmatrix','lagmatrix')
    load('data/hlast5','last5')
    load('data/hxfin','xfin')

end
    
%Parameters to determine convergence
threshold1 = .01;
threshold2 = 10^-5;
odeopts=odeset('RelTol',1e-12,'Events',@virophagedeath_event);

%Append on to previous data if it exists otherwise create data from
%beginning
try
    initsize = size(lagmatrix,1);
catch
    initsize = 0;
end


%Run through each parameter set, integrate dynamics until convergence to
%limit cycle, then determine phase lags
for jj=(initsize+1):size(limpop,1)
    sample=jj;
    tf = 500;       %initial integration time
    onrand = 1;     %initial perturbation to coexistence equilibrium
    initcond = (1+onrand).*limpop(sample,:);
    
    %integrate forward by tf
    [t,x,TE,VE,IE] = ode45(@model_hinfect,[0 tf],initcond,odeopts, limpar(sample,:));
    count1=0;
    
    %if the virophage crash perform smaller perturbation
    if t(end)~= tf && count1 < 3
        onrand = onrand*.1;
        initcond = (1+onrand).*limpop(sample,:);
        count1=count1+1;
        [t,x,TE,VE,IE] = ode45(@model_hinfect,[0 tf],initcond,odeopts, limpar(sample,:));
    end
    
    %Extend dynamics by 25*tf
    [t,x,avg_p] = hextend_nopks(t,x,25,limpar(sample,:),tf);
    
    %If the virophage crash reduce initial perturbation once more
    if t(end)~= tf
        onrand = onrand*.1;
        initcond = (1+onrand).*limpop(sample,:);
        [t,x,TE,VE,IE] = ode45(@model_hinfect,[0 tf],initcond,odeopts, limpar(sample,:));
        %Extend by 50*tf
        [t,x,avg_p] = hextend_nopks(t,x,50,limpar(sample,:),tf);
    end
    
    
    %If Crash output NaNs
    if t(end)~=tf
        lagmatrix(sample,:)= NaN*ones(1,4);
        last5(sample,:)= NaN*ones(1,5);
        xfin(sample,:) = NaN*ones(1,4);
    else
        %Check if avg_p does not deviate
        totalchange = checkavg_p(avg_p);
        checkchange = totalchange./avg_p(end);  %sum of slopes relative to population
        count3=0;
        
        %Extend further until relative sum of virophage slopes indicates
        %convergence to limit cycle or until count reaches 100
        while checkchange>threshold1 & count3<100
            count3 = count3+1;
            [t,x,avg_p] = hextend_nopks(t,x,25,limpar(sample,:),tf);
            totalchange = checkavg_p(avg_p);
            checkchange = totalchange./avg_p(end);
        end
        
        %If convergence occurs determine the phase lags relative to Host
        %population, last 5 populations (to check convergence), and final
        %population to use as initial condition on a limit cycle
        if checkchange<=threshold1
            
            try
                [lagmatrix(sample,:),last5(sample,:),xfin(sample,:)] = phaselag(x,t,1);
                count4 = 0;
                %If last5 differ enough extend dynamics for better convergence
                %to limit cycle
                while abs(sum(diff(last5(sample,:))))>threshold2 & count4<10
                    [t,x,avg_p] = hextend_nopks(t,x,25,limpar(sample,:),tf);
                    count4 = count4+1;
                    [lagmatrix(sample,:),last5(sample,:),xfin(sample,:)] = phaselag(x,t,1);
                end
        
            %If above doesn't work then the dynamics are not long enough to
            %get the 5 peaks required in phaselag.  So extend time and
            %rerun
            catch
            
                tf=tf*2;
                [t,x,TE,VE,IE] = ode45(@model_hinfect,[0 tf],initcond,odeopts, limpar(sample,:));
                
                %Extend with longer time if not converged sufficiently to
                %limit cylce
                try
                    [lagmatrix(sample,:),last5(sample,:),xfin(sample,:)] = phaselag(x,t,1);
                    count4 = 0;
                    while abs(sum(diff(last5(sample,:))))>threshold2 & count4<10
                        [t,x,avg_p] = hextend_nopks(t,x,25,limpar(sample,:),tf);
                        count4 = count4+1;
                        [lagmatrix(sample,:),last5(sample,:),xfin(sample,:)] = phaselag(x,t,1);
                    end
                
                %if extended time does not give enough peaks output zeros
                %along with final populations so that user can fix this
                %manually
                catch
                    lagmatrix(sample,:)= 0*ones(1,4);
                    last5(sample,:)= 0*ones(1,5);
                    xfin(sample,:) = x(end,4);
                end
            end
            
            %If not converged output zeros and last population so user can
            %address this manually
        else
                lagmatrix(sample,:)= 0*ones(1,4);
                last5(sample,:)= 0*ones(1,5);
                xfin(sample,:) = x(end,4);
        end
        
    end
    %Save data on each iteration
    save('data/hlagmatrix','lagmatrix')
    save('data/hlast5','last5')
    save('data/hxfin','xfin')
end