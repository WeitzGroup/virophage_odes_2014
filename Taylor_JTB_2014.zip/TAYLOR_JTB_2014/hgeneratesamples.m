function s = hgeneratesamples(numsamps,ordersmag)

%samples parameter space by LHS around reference parameters in Hinfect model
%
%Input: numsamps -- number of samples
%       ordersmag-- orders of magnitude above and below reference
%                   parameters to sample in log space
%
%Output:    s    -- output parameter sets numsamps x 11 matrix

        reference_params = parameters(2); %hinfect reference parameters
        reference_array = struct2array(reference_params);
        numparams = numel(reference_array);
        numlinparams = 2;   %number of params to sample linearly, at end of parameter array

        % Use LHS to sample log parameters
s = LHSmid(numsamps,ones(numparams-numlinparams,1).*(-1.*ordersmag),ones(numparams-numlinparams,1).*ordersmag);
prodmat = repmat(reference_array(1:numparams-numlinparams),numsamps,1);
s = prodmat.*(10.^s);

%sample lin parameters by LHS between 0 and 1
addcol = linspace(0+.5/numsamps,1-.5/numsamps,numsamps);
addcol = addcol(randperm(numsamps));
addcol2 = addcol(randperm(numsamps));
s = [s, addcol',addcol2'];
