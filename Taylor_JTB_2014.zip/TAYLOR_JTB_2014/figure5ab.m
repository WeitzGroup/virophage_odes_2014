%Figure 5ab: Hinfect virophage effect on host/virus

%grab data
clear all
[totalpops,totalpars,totaleigs] = grabdatah(10);


%Allow points with virophage populations greater that 10^-7
[trimpop,trimpar,trimeig] = feasibledata(totalpops,totaleigs,totalpars,10^(-7));
clear('totalpops'); clear('totalpars'); clear('totaleigs');

%Consider only stable coexistence points

isstable = sum(trimeig>=0,2)<1; %only points with all negative eigenvalues
coexpop = trimpop(isstable,:);  %populations
coexpar = trimpar(isstable,:);  %respective parameters
coexeig = trimeig(isstable,:);  %respective eigenvalues

hvpop = hvonly(coexpar);    %boundary equilibria populations


%figure5a: Virophage affect on Host
figure(1)
scatterhist(log10(hvpop(:,1)),log10(coexpop(:,1)+coexpop(:,4)))
title('Effect of P on H in IEM','Fontsize',20)
ylabel('Log_{10} H+H_p density w/ P','Fontsize',20)
xlabel('Log_{10} H density w/o P','Fontsize',20)
set(gca,'Fontsize',20)
hold on
loglog([min(log10(hvpop(:,1)))  max(log10(coexpop(:,1)+coexpop(:,4)))],[min(log10(hvpop(:,1))) max(log10(coexpop(:,1)+coexpop(:,4)))],'r','Linewidth',3)
hold off
axis([min(log10(hvpop(:,1))) max(log10(coexpop(:,1)+coexpop(:,4))) min(log10(hvpop(:,1))) max(log10(coexpop(:,1)+coexpop(:,4)))])


%figure5b: Virophage affect on Virus
figure(2)
scatterhist(log10(hvpop(:,2)),log10(coexpop(:,2)))
title('Effect of P on V in IEM','Fontsize',20)
ylabel('Log_{10} V density w/ P','Fontsize',20)
xlabel('Log_{10} V density w/o P','Fontsize',20)
set(gca,'Fontsize',20)
hold on
loglog([min(log10(coexpop(:,2)))  max(log10(coexpop(:,2)))],[min(log10(coexpop(:,2)))  max(log10(coexpop(:,2)))],'r','Linewidth',3)
hold off
axis([min(log10(coexpop(:,2)))  max(log10(coexpop(:,2))) min(log10(coexpop(:,2)))  max(log10(coexpop(:,2)))])