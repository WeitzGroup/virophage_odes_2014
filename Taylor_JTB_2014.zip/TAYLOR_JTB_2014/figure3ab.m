%Figure 3ab: Parameter Boxplots


%grab data
clear all
close all
numdatasets = 10;
[totalpopsh,totalparsh,totaleigsh] = grabdatah(numdatasets);
[totalpopsv,totalparsv,totaleigsv] = grabdatav(numdatasets);


%Allow points with virophage populations greater that 10^-7
[trimpoph,trimparh,trimeigh] = feasibledata(totalpopsh,totaleigsh,totalparsh,10^(-7));
clear('totalpopsh','totaleigsh','totalparsh');
[trimpopv,trimparv,trimeigv] = feasibledata(totalpopsv,totaleigsv,totalparsv,10^(-7));
clear('totalpopsv','totaleigsv','totalparsv')


%Take only stable coexistent points

isstableh = sum(trimeigh>=0,2)<1;
coexpoph = trimpoph(isstableh,:);
coexparh = trimparh(isstableh,:);
coexeigh = trimeigh(isstableh,:);

isstablev = sum(trimeigv>=0,2)<1;
coexpopv = trimpopv(isstablev,:);
coexparv = trimparv(isstablev,:);
coexeigv = trimeigv(isstablev,:);




%Figure 3a
%Boxplots for logarithmically sampled parameters

figure(1)
hparstruct = parameters(2);
hpar = struct2array(hparstruct);
vparstruct = parameters(1);
vpar = struct2array(vparstruct);


%Normalize relative to reference value
fixedcoexistparamsh = log10(coexparh(:,1:9))-repmat(log10(hpar(1:9)),size(coexparh,1),1);
fixedcoexistparamsv = log10(coexparv(:,1:9))-repmat(log10(vpar(1:9)),size(coexparv,1),1);

%Create Boexplot
fixedcoexistparamsh = fixedcoexistparamsh';
fixedcoexistparamsv = fixedcoexistparamsv';

%Separate shared parameters from parameters unique to each model
sharedparamsh = fixedcoexistparamsh([1 2 3 5 6 7 8 9],:);
sharedparamsv = fixedcoexistparamsv([1 2 3 5 6 7 8 9],:);
sharedparamsh2 = fixedcoexistparamsh(4,:);
sharedparamsv2 = fixedcoexistparamsv(4,:);

%Interleave with NaNs to obtain spacing and coloring of figure
Nanmat= NaN.*ones(size(sharedparamsh))';
Nanmat3 = NaN.*ones(size(sharedparamsh2))';
col_interleave1 = reshape([sharedparamsh(:) Nanmat(:) Nanmat(:)]',3*size(sharedparamsh,1), [])';
col_interleave1 = [col_interleave1 sharedparamsh2' Nanmat3 Nanmat3 Nanmat3 Nanmat3];
boxPlot(col_interleave1,'b',3)
fixedcoexistparamsv = sharedparamsv';
Nanmat2= NaN.*ones(size(sharedparamsv))';
Nanmat4 = NaN.*ones(size(sharedparamsv2))';
col_interleave2 = reshape([Nanmat2(:) sharedparamsv(:) Nanmat2(:)]',3*size(sharedparamsv,1), [])';
col_interleave2 = [col_interleave2  Nanmat4 Nanmat4 Nanmat4 Nanmat4 sharedparamsv2'];

%boxplot
boxPlot(col_interleave2,'r',3)

%format figure
title('Logarithmically Sampled Paramaters','FontSize',20)
ylabel('Log_{10}(distance from reference)','FontSize',20)
xtickvec = 1.5:3:28.5;
set(gca,'Xtick',xtickvec,'FontSize',20)
format_ticks(gca,{'b','d','K','\phi_v','\beta_v','m_v','m_p','\rho_p','\phi_{p}','\phi_{vp}'})
set(gca,'Fontsize',20)


%Figure 3b
%Boxplots for linearly sampled parameters

figure(2)
hparstruct = parameters(2);
hpar = struct2array(hparstruct);
vparstruct = parameters(1);
vpar = struct2array(vparstruct);


fixedcoexistparamsh = coexparh(:,10:11);
fixedcoexistparamsv = coexparv(:,10:11);


%Interleave with NaNs to obtain spacing and coloring of figure
fixedcoexistparamsh = fixedcoexistparamsh';
fixedcoexistparamsv = fixedcoexistparamsv';
sharedparamsh = fixedcoexistparamsh(1,:);
sharedparamsv = fixedcoexistparamsv(1,:);
sharedparamsh2 = fixedcoexistparamsh(2,:);
sharedparamsv2 = fixedcoexistparamsv(2,:);
Nanmat= NaN.*ones(size(sharedparamsh))';
Nanmat3 = NaN.*ones(size(sharedparamsh2))';
col_interleave1 = reshape([sharedparamsh(:) Nanmat(:) Nanmat(:)]',3*size(sharedparamsh,1), [])';
col_interleave1 = [col_interleave1 sharedparamsh2' Nanmat3 Nanmat3 Nanmat3 Nanmat3];
boxPlot(col_interleave1,'b',3)
fixedcoexistparamsv = sharedparamsv';
Nanmat2= NaN.*ones(size(sharedparamsv))';
Nanmat4 = NaN.*ones(size(sharedparamsv2))';
col_interleave2 = reshape([Nanmat2(:) sharedparamsv(:) Nanmat2(:)]',3*size(sharedparamsv,1), [])';
col_interleave2 = [col_interleave2 Nanmat4 Nanmat4 Nanmat4 Nanmat4 sharedparamsv2'];

%boxplot
boxPlot(col_interleave2,'r',3)

%format figure
title('Linearly Sampled Parameters','FontSize',20)
ylabel('Value','FontSize',20)
set(gca,'Xtick',1.5:3:7.5,'FontSize',20)
format_ticks(gca,{'\rho_{vp}','\rho','\rho_{i}'})
set(gca,'Fontsize',20)

%plot reference values for linearly spaced parameters
pem_refpar = parameters(1);
iem_refpar = parameters(2);
hold on
plot(1,iem_refpar.rhovp,'*b')
plot(2,pem_refpar.rhovp,'*r')
plot(4,iem_refpar.rho,'*b')
hold off