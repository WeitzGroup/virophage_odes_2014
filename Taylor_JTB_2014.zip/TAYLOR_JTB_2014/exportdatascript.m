%Script to export samples of from parameter space of virophage models using
%Latin Hypercube Sampling.  The naming convention are PEM_n and IEM_n where
%n is the number of the resampling.


exportv = 1;    %1 means yes, all else means no
exporth = 1;    %1 means yes, all else means no
numsamps = 100000;  %Number of Samples
ordersmag = 1;  %Order of magnitude to sample from for logarithmically sampled parameters

if exportv==1
    v = vgeneratesamples(numsamps,ordersmag);
    save '/data/PEM_1' v -ASCII -DOUBLE
end

if exporth==1
    h = hgeneratesamples(numsamps,ordersmag);
    save '/data/IEM_1' h -ASCII -DOUBLE
end