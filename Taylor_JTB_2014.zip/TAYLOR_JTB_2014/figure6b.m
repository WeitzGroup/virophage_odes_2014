close all
[totalpops,totalpars,totaleigs] = grabdatav(10);

%Allow points with virophage populations greater that 10^-7
[trimpop,trimpar,trimeig] = feasibledata(totalpops,totaleigs,totalpars,10^(-7));
clear('totalpops'); clear('totalpars'); clear('totaleigs');

%Consider only stable coexistence points

isstable = sum(trimeig>=0,2)<1;
coexpop = trimpop(isstable,:);
coexpar = trimpar(isstable,:);
coexeig = trimeig(isstable,:);



%Bistable figure start
hvpop = hvonly(coexpar);
vposhv = sum(hvpop>0,2);
hvpop(vposhv<2,:) = 0;
hvpop = [hvpop zeros(size(hvpop,1),2)];
eigstable = zeros(size(hvpop,1),4);
vhvstable = false(size(hvpop,1),4);
for k=1:size(hvpop,1)
    eigstable(k,:) = vinfect_eigcheck(hvpop(k,:),coexpar(k,:));
    vhvstable(k,1) = (numel(eigstable(k,real(eigstable(k,:))>=0))==0);
end




%sort by closeness to reference
clear logdistpars
clear hvpop
bistableind = find(vhvstable);
bipar = coexpar(bistableind,:);
bieig = coexeig(bistableind,:);
bipop = coexpop(bistableind,:);


%Previously saved data.  To rerun data use bisection_script.m 
load('data/lastup_fromboundary');
load('data/lastdown_fromboundary');

npts = length(lastup);
lastdown(lastdown==6) = NaN;
lastup(lastup==6) = NaN;
lastdown(lastdown==-6) = NaN;
lastup(lastup==-6) = NaN;
figure(1)
hist(log10(bipop(1:npts,3)'.*(10.^((lastup+lastdown)/2))),100)
xlim([2,12])
%title('Virophage Required for Invasion','FontSize',20)
ylabel('Frequency','FontSize',20)
xlabel('Log_{10}(Virophage Density) in ml^{-1}','FontSize',20)
set(gca,'FontSize',20)