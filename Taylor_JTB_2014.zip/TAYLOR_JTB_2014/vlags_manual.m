%%
%Script for calculating phase lags between populations during cyclical
%dynamics
%
%grab data
clear all
[totalpops,totalpars,totaleigs] = grabdatav(10);

%%
%Allow points with virophage populations greater that 10^-7
[trimpop,trimpar,trimeig] = feasibledata(totalpops,totaleigs,totalpars,10^(-7));
clear('totalpops'); clear('totaleigs'); clear('totalpars');
%%
%Trim data for potential cyclical dynamics
isstable = sum(trimeig>=0,2)>0;
limpop = trimpop(isstable,:);
limpar = trimpar(isstable,:);
limeig = trimeig(isstable,:);
clear('trimpop'); clear('trimpar'); clear('trimeig');
%%
%sort by closeness to reference parameter set with respect to birth and
%death only
sortparind = sortparsv_bd(limpar);    %sort based on proximity to b,d params only
%%
%load previous data if it exists
load('data/vlagmatrix_close','lagmatrix')
load('data/vlast5_close','last5')
load('data/vxfin_close','xfin')
%%
%Integrate dynamics from some initial perturbation
jj=1;
sample=sortparind(jj);
tf = 500;
onrand = .01;
odeopts=odeset('RelTol',1e-12,'Events',@virophagedeath_event);
initcond = (1+onrand).*limpop(sample,:);
[t,x,TE,VE,IE] = ode45(@model_vinfect,[0 tf],initcond,odeopts, limpar(sample,:));
figure(1)
semilogy(t,x)
%%
%Integrate dynamics from some previous final population
jj=1;
sample=sortparind(jj);
tf = 500;
odeopts=odeset('RelTol',1e-12,'Events',@virophagedeath_event);
initcond = xfin(jj,:);
[t,x,TE,VE,IE] = ode45(@model_vinfect,[0 tf],initcond,odeopts, limpar(sample,:));
figure(1)
semilogy(t,x)
%%
%extend dynamics and visualize to see if transients have died down
[t,x,avg_p] = vextend_nopks(t,x,100,limpar(sample,:),tf);
semilogy(avg_p)
%%
%perform phase lag analysis once transients have died down
fracofdyn=1;  %latter fraction of dynamics to use in analysis.  Must
                %be large enough to get 5 peaks for each population.
[lagmatrix(sample,:),last5(sample,:),xfin(sample,:)] = phaselag(x,t,fracofdyn);
%%
%save the data
save('data/vlagmatrix_close','lagmatrix')
save('data/vlast5_close','last5')
save('data/vxfin_close','xfin')
%%
%Visualize in phase subspace V and P alone.  Can visually check for
%convergence
loglog(x(:,2),x(:,3),'Linewidth',3)
title('Phase Space Trajectory on Limit Cycle','Fontsize',20)
xlabel('V Density (ml^{-1})','Fontsize',20)
ylabel('P Density (ml^{-1})','Fontsize',20)
axis([.9*min(x(:,2)) 1.1*max(x(:,2)) .9*min(x(:,3)) 1.1*max(x(:,3))])
hold on
i=length(x)-250; ii=i+2; arrowhead([x(i,2) x(ii,2)],[x(i,3) x(ii,3)],[],[1.5 1.5]);
i=length(x)-750; ii=i+2; arrowhead([x(i,2) x(ii,2)],[x(i,3) x(ii,3)],[],[1.5 1.5]);
set(gca,'Fontsize',20)
hold off