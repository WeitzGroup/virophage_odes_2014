function [lagmatrix,last5,xfin] = phaselag(x,t,dynfrac)

%function [lagmatrix,period,periostd] = lagfunc(x,t)
%
%given assumed cyclical time series of population dynamics this calculates 
%the period oscillation for each population, the coefficient of error of
%the period, and a matrix of lags between 2 populations as fraction of
%average periods.  This function is useful when the periods are nearly the
%same.
%
%Input: x- matrix of populations dynamics with columns as populations
%       t- vector of times with same length as x.
%       dynfrac - amount of dynamics from the end that is considered, this
%       is important to ignore transients.  This value is between 0 and 1.
%       A value of 1 means the entire dynamics are used.  A value of .5
%       means the latter half of the dynamics are used.  A value of 0 means
%       no dynamics are considered.
%
%Output:lagmatrix - matrix of time lags in terms of average periods between
%   populations.
%       last5 - last 5 peaks for H population.
%       xfin - final populations, useful for extending dynamics
%------------------------------------------------------------------------

%ignore transients and consider last dynfrac of dynamics only
xfin = x(end,:);
numpops = size(x,2);
trimt = t(t>(t(end)*(1-dynfrac)));
trimx = x((end-length(trimt)+1):end,:);

for k=1:numpops
    [~,pkinds{k}] = findpeaks(trimx(:,k),'MINPEAKHEIGHT',mean(trimx(:,k)));
end


last5 = log10(trimx(pkinds{1}(end-4:end),1)./mean(trimx(:,1)));

%bound number of peaks based on dynamics of first population
numpeaks = min([length(pkinds{1}),length(pkinds{2}),length(pkinds{3}),length(pkinds{4})]);

period = zeros(1,numpops);

%get the period times for the other population

for j=1:numpops
    peaktimes{j} = trimt(pkinds{j}(1:numpeaks));
    period(j) = mean(diff(peaktimes{j}));
end

%find lag matrix
lagmatrix=zeros(1,numpops);
for j=1:numpops
    lagmatrix(1,j) = mod(mean(2*(peaktimes{j}-peaktimes{1})/(period(j)+period(1))),1);
end