function s = hvonly(p)

%outputs boundary equilibrium for given parameter set
%
%Input: p - vector of parameter values
%
%Ouput: s - vector of boundary equilibrium where H>0,V>0 only

b = p(:,1);
d = p(:,2);
K =p(:,3);
phiv = p(:,5);
betav = p(:,6);
mv = p(:,7);

s = [mv./(betav.*phiv),(b-d.*(1+mv./(betav.*phiv.*K)))./phiv];