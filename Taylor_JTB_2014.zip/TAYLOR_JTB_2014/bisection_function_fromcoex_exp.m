function [lastup,lastdown] = bisection_function_fromcoex_exp(lastup,lastdown,numiters,pop,par,coexpop,minthresh,maxthresh,maxmaxthresh,tfmin,totcounts)


%-------------------------------------------------------------------------
%runs bisection method for identifying boundary of the basin of attraction
%along the virophage axis of phase space along the boundary equilibrium
%slice (specifically H=H_b V=V_b V_p = 0)
%
%Input: lastup -- maximum virophage density boundary for bisection
%       lastdown -- minimum virophage density boundary for bisection
%       numiters -- maximum number of bisections to be taken
%       pop     -- population that is perturbed (H=1,V=2,P=3,Vp=4)
%       par     -- parameter set
%       coexpop   -- coexistence equilibrium
%       minthresh -- fraction of virophage coexistence equilibrium below
%                       which the population is considered to crash
%       maxthresh -- fraction of virophage coexistence equilibrium above
%                       which the population is considered to have fixed as
%                       long as it is below maxmaxthresh
%       maxmaxthresh -- fraction of virophage coexistence equilibrium below
%                       which the population is considered to have fixed as
%                       long as it is above maxthresh
%       tfmin   -- Minimum time to integrate the dynamics
%       totcounts -- number of times to extend integration time by 300%
%
%Output: lastup -- upperbound on the boundary of the basin of attraction
%        lastdown -- lowerbound on the boundary of the basin of attraction
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%initialize k
k=0;


%Check if coexistence occurs at the end of the range

initp = lastdown;   %log10 value
initpact = (10^initp).*coexpop(pop);    %inital population value (after perturbation)
xinit = coexpop;
xinit(pop) = initpact;
[ratout,xfin]= virophage_convergence(coexpop(3),xinit,par,...
    tfmin,minthresh,maxthresh,maxmaxthresh,totcounts);
                
                
%Final check convergence and track if virophage fixed or crashed
                
%Fixed to Coexistence, basin of attraction is outside range.  Output
%NaNs and exit simulation.
    
if (ratout>maxthresh && ratout<maxmaxthresh && xfin(1)>10^(-30) && xfin(2)>10^(-30))
	lastup = NaN;
	lastdown = NaN;
        
	k=numiters;
                    
	%If crashed, do nothing proceed with bisection
                    
    
    %Neither crash nor fix, Prematurely end loop
elseif (ratout<maxthresh || ratout>maxmaxthresh) && ratout>minthresh && xfin(1)>10^(-30) && xfin(2)>10^(-30)
	k=numiters;
end



%bisect a number of predetermined times
while k < numiters
    k=k+1;
    initp = lastup-((lastup - lastdown)./2);    %bisect in log space
    initpact = (10^initp).*coexpop(pop);
    xinit(pop) = initpact;
    [ratout,xfin]= virophage_convergence(coexpop(3),xinit,par,tfmin,minthresh,maxthresh,maxmaxthresh,totcounts);
                
                
    %Final check convergence and track if virophage fixed or crashed
                
    %Fixed and H and V did not crash
    if (ratout>maxthresh && ratout<maxmaxthresh && xfin(1)>10^(-30) && xfin(2)>10^(-30))
        lastup = initp;
                    
        %Crashed
    elseif ratout<minthresh || xfin(1)<10^(-30) || xfin(2)<10^(-30)
        lastdown = initp;
                    
        %Neither, Prematurely end loop
    elseif (ratout<maxthresh || ratout>maxmaxthresh) && ratout>minthresh && xfin(1)>10^(-30) && xfin(2)>10^(-30)
        k=numiters;
    end
end