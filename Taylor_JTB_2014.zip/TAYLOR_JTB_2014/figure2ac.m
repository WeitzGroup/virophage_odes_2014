%Figure 2ac: Hinfect stable and cyclical dynamics


%grab data
clear all
[totalpops,totalpars,totaleigs] = grabdatah(10);


%Allow points with virophage populations greater that 10^-7
[trimpop,trimpar,trimeig] = feasibledata(totalpops,totaleigs,totalpars,10^(-7));
clear('totalpops'); clear('totalpars'); clear('totaleigs');

%Consider only stable coexistence points

isstable = sum(trimeig>=0,2)<1; %only points with all negative eigenvalues
coexpop = trimpop(isstable,:);  %populations
coexpar = trimpar(isstable,:);  %respective parameters
coexeig = trimeig(isstable,:);  %respective eigenvalues


sortparind = sortparsh(coexpar);    %Sort parameters by distance from reference

%figure2a: Stable Coexistence Dynamics figure
sample=sortparind(1);
tf = 500;
onrand = .1;    %perturb from equilibrium by 10%
odeopts=odeset('RelTol',1e-12);

figure(1)
[t,x] = ode45(@model_hinfect,[0 tf],(1+onrand).*coexpop(sample,:),odeopts, coexpar(sample,:));
semilogy(t,x,'Linewidth',3)
axis([0 500 10^0 10^8])
title('Coexistence in IEM','Fontsize',20)
ylabel('Density (ml^{-1})','Fontsize',20)
xlabel('Time (days)','Fontsize',20)
set(gca,'Fontsize',20)
h_leg = legend('H','V','P','H_p','Location','Northwest');


%Cyclical Dynamics figure
clear isstable
isstable = sum(trimeig>=0,2)==2;    %2 positive eigenvalues near hopf
limpop = trimpop(isstable,:);       %populations
limpar = trimpar(isstable,:);       %respective parameters
limeig = trimeig(isstable,:);       %respective eigenvalues

sortparind = sortparsh(limpar);

%load previous initial conditions for cyclical dynamics
load('data/hxfin','xfin')

%Limit cycle example
sample=sortparind(1);
tf = 1000;
odeopts=odeset('RelTol',1e-12,'Events',@virophagedeath_event);
initcond = xfin(sample,:);
[t,x] = ode45(@model_hinfect,[0 tf],initcond,odeopts, limpar(sample,:));


figure(2)
%Cyclical dynamics
semilogy(t,x,'LineWidth',3)
axis([700 850 .3 10^6])
title('Limit Cycle Dynamics in IEM','Fontsize',20)
ylabel('Density (ml^{-1})','Fontsize',20)
xlabel('Time (days)','Fontsize',20)
set(gca,'Fontsize',20)
h_leg = legend('H','V','P','H_p','Location','Northwest');


figure(3)
%Appendix figure: phase plane of cylical dyanmics
loglog(x(:,2),x(:,3),'Linewidth',3)
title('Phase Space Trajectory on Limit Cycle','Fontsize',20)
xlabel('V Density (ml^{-1})','Fontsize',20)
ylabel('P Density (ml^{-1})','Fontsize',20)
axis([.5*min(x(:,2)) 1.5*max(x(:,2)) .9*min(x(:,3)) 1.1*max(x(:,3))])

%Arrowheads
hold on
i=length(x)-250; ii=i+2; arrowhead([x(i,2) x(ii,2)],[x(i,3) x(ii,3)],[],[1.5 1.5]);
i=length(x)-750; ii=i+2; arrowhead([x(i,2) x(ii,2)],[x(i,3) x(ii,3)],[],[1.5 1.5]);
set(gca,'Fontsize',20)
hold off