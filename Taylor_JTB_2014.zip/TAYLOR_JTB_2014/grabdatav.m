function [totalpops,totalpars,totaleigs] = grabdatav(numdatasets)

%function that combines multiple data sets for Vinfect model
%
%Input:  numdatasets -- Number of data sets in data directory
%
%Output: totalpops   -- Combined population data
%        totalpars   -- Combined parameter sets
%        totaleigs   -- Combined eigenvalues for linear stability

totalpops = [];
totalpars = [];
totaleigs = [];

for k=1:numdatasets
    load(strcat('data/PEM_pops',num2str(k),'.dat'));
    load(strcat('data/PEM_pars',num2str(k),'.dat'));
    load(strcat('data/PEM_eigs',num2str(k),'.dat'));
    
    eval(strcat('totalpops = [totalpops; PEM_pops',num2str(k),'];'));
    eval(strcat('totalpars = [totalpars; PEM_pars',num2str(k),'];'));
    eval(strcat('totaleigs = [totaleigs; PEM_eigs',num2str(k),'];'));
    
    eval(strcat('clear PEM_pops',num2str(k)));
    eval(strcat('clear PEM_pars',num2str(k)));    
    eval(strcat('clear PEM_eigs',num2str(k)));
end