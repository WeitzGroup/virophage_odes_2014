function p = parameters(n)

%Obtain structure of reference parameter set for either model
%
%Input: n - value that indicates model.  1 outputs Vinfect model, all else
%           for Hinfect model
%
%Output:p - structure with respective parameter set
if n == 1
        p.b = 1.4;
        p.d = 1.4/2;
        p.K = 4*10^6;
        p.phivp = 4.37*10^(-6)/2;
        p.phiv = 8.63*10^(-6)/2;
        p.betav = 300;
        p.mv = .0316;
        p.mp = .316;
        p.rhop = 10;
        p.rhovp = .3;
        p.rhoi = .05;
else
        p.b = 2.7;
        p.d = 2.7/2;
        p.K = 4*10^6;
        p.phip = 2.16*10^(-5)/2;
        p.phiv = 4.31*10^(-6)/2;
        p.betav = 133;
        p.mv = .0632;
        p.mp = .316;
        p.rhop = 7.5;
        p.rhovp = .3;
        p.rho = .5;
end