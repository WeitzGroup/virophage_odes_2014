%Figure 2bdapp: Vinfect stable and cyclical dynamics


%grab data
close all
clear all
[totalpops,totalpars,totaleigs] = grabdatav(10);


%Allow points with virophage populations greater that 10^-7
[trimpop,trimpar,trimeig] = feasibledata(totalpops,totaleigs,totalpars,10^(-7));
clear('totalpops'); clear('totalpars'); clear('totaleigs');

%Consider only stable coexistence points

isstable = sum(trimeig>=0,2)<1;
coexpop = trimpop(isstable,:);
coexpar = trimpar(isstable,:);
coexeig = trimeig(isstable,:);


sortparind = sortparsv(coexpar);    %Sort parameters by distance from reference

%figure2b: Stable Coexistence Dynamics figure
sample=sortparind(1);
tf = 500;
onrand = .1;    %perturb from equilibrium by 10%
odeopts=odeset('RelTol',1e-12);

[t,x] = ode45(@model_vinfect,[0 tf],(1+onrand).*coexpop(sample,:),...
    odeopts, coexpar(sample,:));

figure(1)
semilogy(t,x,'Linewidth',3)
title('Coexistence in PEM','Fontsize',20)
ylabel('Density (ml^{-1})','Fontsize',20)
xlabel('Time (days)','Fontsize',20)
ylim([10^0 10^8])
set(gca,'Fontsize',20)
h_leg = legend('H','V','P','V_p','Location','Northwest');


%Cyclical Dynamics figure
clear isstable
isstable = sum(trimeig>=0,2)==2;    %2 positive eigenvalues near hopf
limpop = trimpop(isstable,:);
limpar = trimpar(isstable,:);
limeig = trimeig(isstable,:);

sortparind = sortparsv_bd(limpar);

%load previous initial conditions for cyclical dynamics
load('data/vxfin_close','xfin')

%Limit cycle example
jj=22;
sample=sortparind(jj);
x = xfin(jj,:);
odeopts=odeset('RelTol',1e-12,'Events',@virophagedeath_event);
tf=1000;
[t,x,TE,VE,IE] = ode45(@model_vinfect,[0 tf],x(end,:),odeopts, limpar(sample,:));


figure(2)
%Cyclical dynamics
semilogy(t,x,'LineWidth',3)
title('Limit Cycle Dynamics in PEM','Fontsize',20)
ylabel('Density (ml^{-1})','Fontsize',20)
xlabel('Time (days)','Fontsize',20)
set(gca,'Fontsize',20)
axis([700 850 .3 10^6])
h_leg = legend('H','V','P','V_p','Location','Southwest');


figure(3)
%Appendix figure: phase plane of cylical dyanmics
loglog(x(:,2),x(:,3),'Linewidth',3)
title('Phase Space Trajectory on Limit Cycle','Fontsize',20)
xlabel('V Density (ml^{-1})','Fontsize',20)
ylabel('P Density (ml^{-1})','Fontsize',20)
axis([.9*min(x(:,2)) 1.1*max(x(:,2)) .9*min(x(:,3)) 1.1*max(x(:,3))])

%Arrowheads on phase plane
hold on
i=length(x)-1400; ii=i+2; arrowhead([x(i,2) x(ii,2)],[x(i,3) x(ii,3)],[],[1.5 1.5]);
i=length(x)-3800; ii=i+2; arrowhead([x(i,2) x(ii,2)],[x(i,3) x(ii,3)],[],[1.5 1.5]);
set(gca,'Fontsize',20)
hold off

%Limit cycle appendix example
jj=14;
sample=sortparind(jj);
x = xfin(jj,:);
odeopts=odeset('RelTol',1e-12,'Events',@virophagedeath_event);
tf=1000;
[t,x,TE,VE,IE] = ode45(@model_vinfect,[0 tf],x(end,:),odeopts, limpar(sample,:));


figure(4)
%Cyclical dynamics
semilogy(t,x,'LineWidth',3)
title('Limit Cycle Dynamics in PEM','Fontsize',20)
ylabel('Density (ml^{-1})','Fontsize',20)
xlabel('Time (days)','Fontsize',20)
set(gca,'Fontsize',20)
%axis([700 850 .3 10^6])
h_leg = legend('H','V','P','V_p','Location','Southwest');


figure(5)
%Appendix figure: phase plane of cylical dyanmics
loglog(x(:,2),x(:,3),'Linewidth',3)
title('Phase Space Trajectory on Limit Cycle','Fontsize',20)
xlabel('V Density (ml^{-1})','Fontsize',20)
ylabel('P Density (ml^{-1})','Fontsize',20)
axis([.9*min(x(:,2)) 1.1*max(x(:,2)) .9*min(x(:,3)) 1.1*max(x(:,3))])

%Arrowheads on phase plane
hold on
i=length(x)-1150; ii=i+2; arrowhead([x(i,2) x(ii,2)],[x(i,3) x(ii,3)],[],[1.5 1.5]);
i=length(x)-3800; ii=i+2; arrowhead([x(i,2) x(ii,2)],[x(i,3) x(ii,3)],[],[1.5 1.5]);
set(gca,'Fontsize',20)
hold off