%Figure 6b: Stacked bistable histogram from coexistence
close all
clear all


%Script parameters

npts = 1000;    %total data
histpts = 25;   %number of histogram bars


%Load data obtained from bistable_script_fromcoex* scripts
load('data/lastup_vp_down');
load('data/lastdown_vp_down');

load('data/lastup_vp_up');
load('data/lastdown_vp_up');

load('data/lastup_v_up');
load('data/lastdown_v_up');

load('data/lastup_v_down');
load('data/lastdown_v_down');

load('data/lastup_h_up');
load('data/lastdown_h_up');

load('data/lastup_h_down');
load('data/lastdown_h_down');

load('data/lastup_p_down');
load('data/lastdown_p_down');

load('data/lastup_p_up');
load('data/lastdown_p_up');


%Combine data into cell arrays for easier manipulation
diffcell{1} = lastup_h_up(1:npts)-lastdown_h_up(1:npts);
diffcell{2} = lastup_h_down(1:npts)-lastdown_h_down(1:npts);
diffcell{3} = lastup_v_up(1:npts)-lastdown_v_up(1:npts);
diffcell{4} = lastup_v_down(1:npts)-lastdown_v_down(1:npts);
diffcell{5} = lastup_p_up(1:npts)-lastdown_p_up(1:npts);
diffcell{6} = lastup_p_down(1:npts)-lastdown_p_down(1:npts);
diffcell{7} = lastup_vp_up(1:npts)-lastdown_vp_up(1:npts);
diffcell{8} = lastup_vp_down(1:npts)-lastdown_vp_down(1:npts);

lastdowncell{1} = lastdown_h_up(1:npts);
lastdowncell{2} = lastdown_h_down(1:npts);
lastdowncell{3} = lastdown_v_up(1:npts);
lastdowncell{4} = lastdown_v_down(1:npts);
lastdowncell{5} = lastdown_p_up(1:npts);
lastdowncell{6} = lastdown_p_down(1:npts);
lastdowncell{7} = lastdown_vp_up(1:npts);
lastdowncell{8} = lastdown_vp_down(1:npts);

lastupcell{1} = lastup_h_up(1:npts);
lastupcell{2} = lastup_h_down(1:npts);
lastupcell{3} = lastup_v_up(1:npts);
lastupcell{4} = lastup_v_down(1:npts);
lastupcell{5} = lastup_p_up(1:npts);
lastupcell{6} = lastup_p_down(1:npts);
lastupcell{7} = lastup_vp_up(1:npts);
lastupcell{8} = lastup_vp_down(1:npts);



%Make each histogram separately within subplot

for jj=1:length(lastdowncell)
    
    %Set points outside range to NaN (range is [-1 1]
    %Counts points outside range

    if mod(jj,2)==0
        lastdowncell{jj}(lastupcell{jj}<-.9999) = NaN;
        lastupcell{jj}(lastupcell{jj}<-.9999) = NaN;
        diffcell{jj}(lastupcell{jj}<-.9999) = NaN;
        nanbelow{jj/2} = sum(isnan(lastupcell{jj}));
        subtracter{jj} = nanbelow{jj/2};
    else
        lastdowncell{jj}(lastupcell{jj}>.9999) = NaN;
        lastupcell{jj}(lastupcell{jj}>.9999) = NaN;
        diffcell{jj}(lastupcell{jj}>.9999) = NaN;
        nanabove{(jj+1)/2} = sum(isnan(lastupcell{jj}));
        subtracter{jj} = nanabove{(jj+1)/2};
    end
    
    lastdowncell{jj}(abs(diffcell{jj})>10^(-2)) = NaN;
    lastupcell{jj}(abs(diffcell{jj})>10^(-2)) = NaN;
    nanunconverge{jj} = sum(isnan(lastupcell{jj}))-subtracter{jj};
    
    %Create separate histograms for adding or subtracting resp. populations
    if mod(jj,2)==0
        [histy{jj},histx{jj}] = hist((lastupcell{jj}+lastdowncell{jj})/2,linspace(-1,0-eps,histpts));
    else
        [histy{jj},histx{jj}] = hist((lastupcell{jj}+lastdowncell{jj})/2,linspace(0+eps,1,histpts));
    end
end

%Combine histograms to plot over entire range
for kk = 1:length(lastdowncell)/2
    histyfull{kk} = [histy{2*kk} histy{2*kk-1}];
    histxfull{kk} = [histx{2*kk} histx{2*kk-1}];
    histyfull{kk}(end+1:end+2) = [nanabove{kk} nanbelow{kk}];   %add bar for outside range
    histxfull{kk}(end+1:end+2) = [1.25 -1.25];                  %place outside range
end

%Grab colors to match histogram colors with dynamics plots
close all
h3 = plot(1:10,zeros(10,4));
c2 = get(h3,'Color');
close all
colorcell = c2;
legendcell = {'H','V','P','V_p'};
figure('color', 'w');


%make stacked plots
for jj=1:4
    clear YTick; clear YTickLabel;
    h(jj) = subplot(4,1,jj);
    h1 = bar(histxfull{jj},log10(histyfull{jj}),'hist');
    ylim([0 log10(npts)]);
    xlim([-1.3 1.3])
    h2 = findobj(gca,'Type','line');
    set(h2,'Marker','none');
    set(h1,'FaceColor',colorcell{jj})
    set(gca,'FontSize',14,'Xtick',[-1.25 -1 -0.5 0 0.5 1 1.25],'XTickLabel',{'<-1','-1','-0.5','0','0.5','1','>1'})%,...

    
    %Move Ytick labels to look less cluttered
    set(gca,'YTick',[0 log10(npts)/2 log10(npts)]);
    YTick = get(gca,'YTick');
    for kk = 1:length(YTick)
        YTickLabel{kk} = num2str(YTick(kk));
    end
    ylabel(strcat(legendcell{jj},' Log_{10}(f)'),'FontSize',15)
    set(gca,'YTickLabel',[]);
    XLims = get(gca,'XLim');
    OFFSET = 0.01;
    xtest = XLims(1) - OFFSET*diff(XLims);
    for mm = 1:length(YTickLabel)
        %bump lower limit tick label up
        if mm==1
            hText = text(xtest,0.1*(YTick(end)-YTick(1)),YTickLabel{mm},'Horiz','Right','FontSize',14);        
        %bump upper limit tick label down
        elseif mm==length(YTickLabel)
            hText = text(xtest,.9*YTick(mm),YTickLabel{mm},'Horiz','Right','FontSize',14);    
        %Keep other tick labels in the same spot        
        else
            hText = text(xtest,YTick(mm),YTickLabel{mm},'Horiz','Right','FontSize',14);
        end
    end
    %Bump x-axis up so xlabel is not cut off
    pushup = .03;
    xlabel('Log_{10}(Multiple) of Density','FontSize',16)
    ovec = get(gca,'OuterPosition');
    set(gca,'OuterPosition',[ovec(1) ovec(2) + pushup ovec(3) ovec(4)])
end

%join subplots closer
samexaxis('join','yld',2.6);